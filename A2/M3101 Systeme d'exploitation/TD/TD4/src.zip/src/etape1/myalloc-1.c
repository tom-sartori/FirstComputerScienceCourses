#include "../generic/myalloc.h"
#include "myalloc-bloc-entete-1.h"
#include <stdio.h>




#include "myalloc-1.c.inc"
#include "myfree-1.c.inc"
#include "blocinfo-1.c.inc"
