#include "../generic/myalloc.h"
#include "myalloc-bloc-entete.h"
#include <stdio.h>




#include "myalloc.inc.c"
#include "myfree.inc.c"
#include "blocinfo.inc.c"
