#include "align.h"
#include "entete_size.h"
#include <stdlib.h>

extern void *myalloc(size_t size);
extern void myfree(void* ptr);
extern void bloc_info(void* ptr);
