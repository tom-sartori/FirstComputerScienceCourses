#define ENTETE_SIZE (ALIGN(sizeof(bloc_entete))) 
