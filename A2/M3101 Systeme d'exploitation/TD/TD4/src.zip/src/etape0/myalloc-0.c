#include "../generic/myalloc.h"
#include "myalloc-bloc-entete-0.h"
#include <stdio.h>


#include "myalloc-0.c.inc"
#include "myfree-0.c.inc"
#include "blocinfo-0.c.inc"
