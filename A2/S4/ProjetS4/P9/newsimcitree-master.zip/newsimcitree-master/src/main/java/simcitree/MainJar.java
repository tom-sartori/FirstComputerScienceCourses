package simcitree;

public class MainJar {

    public static void main(String[] args) {
        Main.main(args);
    }
}
