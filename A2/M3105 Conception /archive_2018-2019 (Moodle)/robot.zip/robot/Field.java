import static java.lang.Math.*;

/**
 * Classe pour le terrain où évolueront les objets.
 */

public class Field {

    /**
     * Hauteur et largeur du terrain.
     */
    protected int heigth, width;

    /**
     * Construction d'un terrain de dimensions données.
     *
     * @param h  Hauteur du terrain
     * @param w  Largeur du terrain
     */
    public Field(int h, int w) {
	// À compléter.
    }

    /**
     * Normalisation d'une abscisse.
     *
     * @param x  Abscisse quelconque
     * @return Abscisse normalisée
     */
    public double normalizeX(double x) {
	// À compléter.
	return 0;
    }

    /**
     * Normalisation d'une ordonnée.
     *
     * @param x  Ordonnée quelconque
     * @return Ordonnée normalisée
     */
    public double normalizeY(double y) {
	// À compléter.
	return 0;
    }

}
